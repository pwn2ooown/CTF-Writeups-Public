let res = '6020e9735ca3bf2f63aebcf3622c994880ffed2b509c91414c75d4c500ee80f4'
let hint_pt = '414953337b3f3f3f3f3f3f3f3f3f3f7d'
let hint = '118cd68957ac93b269335416afda70e6d79ad65a09b0c0c6c50917e0cee18c93'
let iv = '4149533320e4b889'

    module.exports = {
        res: res,
        hint: hint,
        iv: iv,
        hint_pt: hint_pt,
    }

