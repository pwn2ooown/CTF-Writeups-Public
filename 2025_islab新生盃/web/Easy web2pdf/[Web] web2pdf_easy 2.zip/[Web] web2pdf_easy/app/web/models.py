import time
import redis
from selenium import webdriver

db = redis.Redis()

PDF_PATH = '/app/web/pdfs/'

class Document:
    @classmethod
    def __init__(self, url, sid):
        self.url = url
        self.fileid = str(round(time.time() * 1000))
        self.html2pdf(url)
        self.save(sid)

    @classmethod
    def html2pdf(self, url):
        driver = webdriver.PhantomJS(service_log_path='/dev/null')
        driver.get(url)
        
        # hack while the python interface lags
        driver.command_executor._commands['executePhantomScript'] = ('POST', '/session/$sessionId/phantom/execute')
        
        # set page format
        # inside the execution script, webpage is "this"
        page_format = 'this.paperSize = {format: "A4", orientation: "portrait" };'
        driver.execute('executePhantomScript', {'script': page_format, 'args': []})
        
        render = '''this.render("{}")'''.format(PDF_PATH + self.fileid + '.pdf')
        driver.execute('executePhantomScript', {'script': render, 'args': []})

    @classmethod
    def save(self, sid):
        if sid != '':
            db.hset(sid, self.url, self.fileid)
            db.expire(sid, 15 * 60) #refresh session

    @staticmethod
    def list(sid):
        if sid != '':
            docs = db.hgetall(sid)
            docs = { key.decode(): '/api/download?id=' + val.decode() for key, val in docs.items() }
            return docs



