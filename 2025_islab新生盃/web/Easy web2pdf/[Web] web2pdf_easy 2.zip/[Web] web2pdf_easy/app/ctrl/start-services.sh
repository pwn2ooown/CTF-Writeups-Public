#!/bin/sh

# replace dynamic flag
sed -i 's/flag{fake_flag}/'"$GZCTF_FLAG"'/' /flag
export GZCTF_FLAG=not_flag
GZCTF_FLAG=not_flag

#launch redis
cd /app/db/
redis-server /app/db/redis.conf &

#launch nginx
nginx -g "daemon off;" &

#launch crond
cron -f &

#launch uwsgi
cd /app/web/
uwsgi --ini /app/web/uwsgi.ini &

#cleanup files older than 15 minutes, every minute
while sleep 60; do
	find /app/web/pdfs -maxdepth 1 -mmin +15 -type f -exec rm -f {} +
done