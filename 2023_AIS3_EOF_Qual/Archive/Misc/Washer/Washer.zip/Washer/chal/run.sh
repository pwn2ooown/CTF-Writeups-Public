#!/bin/bash
exec 2>/dev/null
timeout 180 /chal
