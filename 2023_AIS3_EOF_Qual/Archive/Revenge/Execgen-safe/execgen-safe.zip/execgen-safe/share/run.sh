#!/bin/sh

exec 2>/dev/null
timeout 30 /home/chal/chal
