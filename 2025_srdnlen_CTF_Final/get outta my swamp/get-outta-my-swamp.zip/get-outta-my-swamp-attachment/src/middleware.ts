
import { NextResponse, NextRequest } from 'next/server';

const SECRET = (process.env.JWT_SECRET || 'mock_value') as string;

function base64UrlToBase64(u: string): string {
  const pad = u.length % 4 === 2 ? '==' : u.length % 4 === 3 ? '=' : '';
  return u.replace(/-/g, '+').replace(/_/g, '/') + pad;
}
function b64urlDecodeToUint8(u: string): Uint8Array {
  const b64 = base64UrlToBase64(u);
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return arr;
}

async function hmacSHA256(keyBytes: ArrayBuffer, data: ArrayBuffer): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey(
    'raw',
    keyBytes,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, data);
  return new Uint8Array(sig);
}

function timingSafeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i++) out |= a[i] ^ b[i];
  return out === 0;
}

async function verifyJwtHS256(token: string, secret: string): Promise<any | null> {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [h, p, s] = parts;
  const data = new TextEncoder().encode(`${h}.${p}`);
  const key = new TextEncoder().encode(secret);
  const expected = await hmacSHA256(key.buffer, data.buffer);
  const sig = b64urlDecodeToUint8(s);
  if (!timingSafeEqual(expected, sig)) return null;
  try {
    const payloadJson = atob(base64UrlToBase64(p));
    return JSON.parse(payloadJson);
  } catch { return null; }
}

export async function middleware(req: NextRequest) {
  const url = req.nextUrl;
  if (!url.pathname.startsWith('/gingerbread-secret')) return NextResponse.next();

  const token = req.cookies.get('jwt')?.value;
  if (!token) { url.pathname = '/login'; return NextResponse.redirect(url); }

  const payload = await verifyJwtHS256(token, SECRET);
  if (payload && payload.role === 'admin' && payload.sub === 'Shrek') {
    return NextResponse.next();
  }
  url.pathname = '/login';
  return NextResponse.redirect(url);
}

export const config = { matcher: ['/gingerbread-secret/:path*'] };
