export const runtime = 'nodejs';

import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';

const BASE = process.env.BASE_URL || 'http://localhost:3000';

export async function POST(request: Request) {
  const { default: db } = await import('@/lib/db');
  const form = await request.formData();
  const username = String(form.get('username') || '').trim();
  const password = String(form.get('password') || '');

  if (!username || !password) {
    return NextResponse.redirect(new URL('/register?e=empty', BASE), 303);
  }
  if (username.length < 3 || username.length > 32) {
    return NextResponse.redirect(new URL('/register?e=uname', BASE), 303);
  }

  const hash = bcrypt.hashSync(password, 10);

  try {
    db.prepare('INSERT INTO users (username, password) VALUES (?, ?)').run(username, hash);
    return NextResponse.redirect(new URL('/login?reg=ok', BASE), 303);
  } catch (err: any) {
    if (err && (err.code === 'SQLITE_CONSTRAINT' || String(err.message).includes('UNIQUE'))) {
      return NextResponse.redirect(new URL('/register?e=exists', BASE), 303);
    }
    return NextResponse.redirect(new URL('/register?e=fail', BASE), 303);
  }
}
