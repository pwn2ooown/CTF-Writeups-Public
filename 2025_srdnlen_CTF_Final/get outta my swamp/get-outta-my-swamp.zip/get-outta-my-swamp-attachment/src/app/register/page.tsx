export default function Register({ searchParams }: { searchParams?: Record<string,string> }) {
  const e = searchParams?.e;
  const msg =
    e === 'exists' ? 'That username is already taken.'
    : e === 'empty' ? 'Please fill in both fields.'
    : e === 'uname' ? 'Username must be 3–32 characters.'
    : e === 'fail'  ? 'Something went wrong. Try again.'
    : searchParams?.reg === 'ok' ? 'Registration successful! Please log in.'
    : null;

  return (
    <main className="row justify-content-center">
      <div className="col-md-6">
        <div className="card swamp p-4">
          <h1 className="h3 mb-3">Register</h1>
          {msg && <div className={`alert ${e ? 'alert-danger' : 'alert-success'}`}>{msg}</div>}
          <form action="/register/new" method="POST" className="vstack gap-3">
            <div>
              <label className="form-label">Username</label>
              <input className="form-control" name="username" required minLength={3} maxLength={32} />
            </div>
            <div>
              <label className="form-label">Password</label>
              <input className="form-control" type="password" name="password" required />
            </div>
            <button className="btn btn-ogre">Create account</button>
          </form>
        </div>
      </div>
    </main>
  );
}
