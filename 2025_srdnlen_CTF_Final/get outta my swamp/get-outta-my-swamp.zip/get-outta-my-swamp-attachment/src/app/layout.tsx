
export const metadata = { title: "srdnlen CTF 2025 · Get Outta My Swamp!" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
          crossOrigin="anonymous"
        />
        <link rel="stylesheet" href="/theme.css"/>
      </head>
      <body>
        <nav className="navbar navbar-expand-lg">
          <div className="container">
            <a className="navbar-brand brand" href="/">
              <img src="/shrek_emoji.png" width="28" height="28" alt="Ogre"/> Get Outta My Swamp!
            </a>
            <button className="navbar-toggler btn btn-sm btn-outline-light" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
              <span className="navbar-toggler-icon" />
            </button>
            <div className="collapse navbar-collapse" id="nav">
              <ul className="navbar-nav ms-auto">
                <li className="nav-item"><a className="nav-link text-light" href="/">Home</a></li>
                <li className="nav-item"><a className="nav-link text-light" href="/about">About</a></li>
                <li className="nav-item"><a className="nav-link text-light" href="/login">Login</a></li>
                <li className="nav-item"><a className="nav-link text-light" href="/profile">Profile</a></li>
                <li className="nav-item"><a className="nav-link text-light" href="/register">Register</a></li>
                <li className="nav-item"><a className="nav-link text-light" href="/characters">Characters</a></li>
              </ul>
            </div>
          </div>
        </nav>
        <div className="container my-4">{children}</div>
        <footer className="py-4">
          <div className="container d-flex justify-content-between align-items-center">
            <span className="chip">Shrek is Love</span>
            <small className="text-light-50">© {new Date().getFullYear()} Get Outta My Swamp!</small>
          </div>
        </footer>
        <script
          src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
          integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
          crossOrigin="anonymous"
        ></script>
      </body>
    </html>
  );
}
