
export default function Login({ searchParams }: { searchParams?: { e?: string } }) {
  const hasError = searchParams?.e === '1';
  return (
    <main className="row justify-content-center">
      <div className="col-md-6">
        <div className="card swamp p-4">
          <h1 className="h3 mb-3">Login</h1>
          {hasError && <div className="alert alert-danger">Wrong Credentials</div>}
          <form action="/login/set" method="POST" className="vstack gap-3">
            <div>
              <label className="form-label">Username</label>
              <input className="form-control" name="username" placeholder="donkey" />
            </div>
            <div>
              <label className="form-label">Password</label>
              <input className="form-control" type="password" name="password" placeholder="waffles" />
            </div>
            <button className="btn btn-ogre">Sign in</button>
          </form>
          <p className="mt-3 text-secondary">Don't have an account? <a href="/register">Register here</a></p>
        </div>
      </div>
    </main>
  );
}
