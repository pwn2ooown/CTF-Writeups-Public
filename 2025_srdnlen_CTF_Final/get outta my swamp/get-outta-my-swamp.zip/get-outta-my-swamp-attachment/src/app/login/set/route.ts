export const runtime = 'nodejs';
const BASE = process.env.BASE_URL;

import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const SECRET = process.env.JWT_SECRET || 'mock_value';

export async function POST(request: Request) {
  const { default: db } = await import('@/lib/db');
  const form = await request.formData();
  const username = String(form.get('username') || '');
  const password = String(form.get('password') || '');
  const row = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!row || !bcrypt.compareSync(password, row.password)) {
    return NextResponse.redirect(new URL('/login?e=1', BASE), 303);
  }
  const token = jwt.sign({ sub: username, role: 'user' }, SECRET, { expiresIn: '1h' });
  const res = NextResponse.redirect(new URL('/profile', BASE), 303);
  res.cookies.set('jwt', token, { httpOnly: true, sameSite: 'lax', path: '/' });
  return res;
}
