export default function About() {
  return (
    <main className="row justify-content-center">
      <div className="col-lg-10">
        <div className="card swamp p-4">
          <h1 className="h3 mb-3">The Shrek Movie Saga</h1>
          <p>
            DreamWorks’ <strong>Shrek</strong> franchise turned the fairy tale genre upside down. 
            With humor, parody, and surprising depth, these movies became a cultural phenomenon, 
            blending satire with heartfelt stories about friendship, identity, and love.
          </p>

          <ul>
            <li>
              <h2 className="h5">Shrek (2001)</h2>
              <p>
                The original film introduces us to Shrek, an ogre who values solitude in his swamp. 
                When fairy-tale creatures invade his home, he strikes a deal with Lord Farquaad: 
                rescue Princess Fiona in exchange for peace and privacy. Along the way, Shrek bonds 
                with the endlessly talkative Donkey and discovers that Fiona holds a secret of her own. 
              </p>
              <p>
                <strong>Themes:</strong> Self-acceptance, looking beyond appearances, and redefining 
                the idea of “happily ever after.”
              </p>
            </li>

            <li>
              <h2 className="h5">Shrek 2 (2004)</h2>
              <p>
                Shrek and Fiona visit her royal parents in the kingdom of Far Far Away, where they face 
                disapproval, plots from the Fairy Godmother, and the scheming Prince Charming. 
                The movie also introduces <em>Puss in Boots</em>, a fan-favorite character with 
                charm, wit, and a devastating “cute” look.
              </p>
              <p>
                <strong>Themes:</strong> Family expectations, cultural clashes, and the power of love 
                against manipulation. <br />
                <strong>Impact:</strong> One of the highest-grossing animated films ever at the time, 
                cementing Shrek as a global brand.
              </p>
            </li>

            <li>
              <h2 className="h5">Shrek the Third (2007)</h2>
              <p>
                With King Harold ill, Shrek must find a rightful heir to the throne—Arthur Pendragon, 
                a reluctant teenager. Meanwhile, Prince Charming rallies villains to seize power. 
                Shrek also grapples with impending fatherhood, questioning his ability to raise children.
              </p>
              <p>
                <strong>Themes:</strong> Responsibility, leadership, and personal growth. <br />
                <strong>Highlights:</strong> Princesses taking charge, a comical medieval high school, 
                and Shrek confronting his deepest insecurities.
              </p>
            </li>

            <li>
              <h2 className="h5">Shrek Forever After (2010)</h2>
              <p>
                Feeling trapped by domestic life, Shrek makes a dangerous deal with Rumpelstiltskin, 
                ending up in an alternate reality where he never existed. To restore his world, 
                he must fight to earn back Fiona’s love and reclaim his true identity.
              </p>
              <p>
                <strong>Themes:</strong> Appreciating what you have, sacrifice, and the importance 
                of chosen family. <br />
                <strong>Tone:</strong> Darker and more introspective, but still infused with comedy.
              </p>
            </li>

            <li>
              <h2 className="h5">Puss in Boots (2011) & Puss in Boots: The Last Wish (2022)</h2>
              <p>
                These spin-offs focus on the daring swashbuckler Puss in Boots. The first film explores 
                his origin story, rivalry with Humpty Dumpty, and quest for the Golden Goose. The sequel, 
                <em>The Last Wish</em>, tackles mortality as Puss discovers he is on his last life and 
                must seek the mythical Last Wish to restore them.
              </p>
              <p>
                <strong>Themes:</strong> Legacy, mortality, courage, and second chances. <br />
                <strong>Impact:</strong> <em>The Last Wish</em> received critical acclaim for its 
                animation style, emotional storytelling, and bold new direction.
              </p>
            </li>
          </ul>

          <p className="mt-4">
            Across two decades, the Shrek franchise has blended comedy, fairy-tale parody, and 
            heartfelt life lessons. It remains one of the most beloved animated series, quoted 
            endlessly and remembered for showing that even an ogre can be a hero.
          </p>
        </div>
      </div>
    </main>
  );
}
