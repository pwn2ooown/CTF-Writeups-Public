export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export default function GingerbreadSecret() {
  const secret_ingredient = process.env.FLAG || "srdnlen{fake_flag}";
  return (
    <main className="card swamp p-4">
      <h1>Gingerbread Secret 🍪</h1>
      <p className="mb-2"><em>"No one shall ever learn the true recipe of the Gingerbread Man."</em></p>
      <p className="mb-3">…unless they slip through the swamp.</p>
      <pre className="mb-0">{secret_ingredient}</pre>
    </main>
  );
}
