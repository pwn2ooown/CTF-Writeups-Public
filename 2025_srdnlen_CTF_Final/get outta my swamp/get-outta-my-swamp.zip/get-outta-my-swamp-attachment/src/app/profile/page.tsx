
import { cookies } from 'next/headers';

export default async function Profile() {
  const c = await cookies();
  const session = c.get('session')?.value === 'ok';
  return (
    <main className="row justify-content-center">
      <div className="col-md-8">
        <div className="card swamp p-4">
          <h1 className="h3 mb-3">Your Swamp Profile</h1>
          <p>Presence in the swamp: <strong>{session ? 'Welcome guest' : 'Mud intruder'}</strong></p>
          <p className="mb-0">Tip: onions have layers. So does security.</p>
        </div>
      </div>
    </main>
  );
}
