
type Char = { name: string; img: string; bio: string };
const chars: Char[] = [
  { name: "Shrek", img: "/characters/shrek.jpg", bio: "Big green ogre. Guardian of the swamp and 303 redirects." },
  { name: "Donkey", img: "/characters/donkey.jpg", bio: "Chatty and loyal. Favorite password: waffles." },
  { name: "Fiona", img: "/characters/fiona.jpg", bio: "Princess with layers. Loves onion-flavored crypto." },
  { name: "Puss in Boots", img: "/characters/puss.jpg", bio: "Deadly stare, elegant exploits." },
  { name: "Lord Farquaad", img: "/characters/farquaad.jpg", bio: "Tiny emperor of 307s. Loves wrong redirects." },
  { name: "Gingy", img: "/characters/gingy.jpg", bio: "Tenacious cookie. Don’t touch his gumdrop buttons." },
  { name: "Dragon", img: "/characters/dragon.jpg", bio: "Warm breath, warmer logs. Keeper of secrets." }
];

export default function Characters() {
  return (
    <main>
      <h1 className="mb-3">Shrekverse Characters</h1>
      <div className="row g-3">
        {chars.map(c => (
          <div className="col-sm-6 col-md-4" key={c.name}>
            <div className="card swamp p-3 h-100 text-center">
              <img alt={c.name} src={c.img} width="120" height="120" className="mx-auto mb-2" />
              <h5 className="mb-1">{c.name}</h5>
              <p className="mb-0">{c.bio}</p>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
