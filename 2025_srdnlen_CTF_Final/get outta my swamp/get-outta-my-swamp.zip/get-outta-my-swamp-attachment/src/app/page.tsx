
export default function Home() {
  return (
    <main className="hero">
      <div className="d-flex align-items-center gap-3 mb-3">
        <img src="/shrek_emoji.png" width="28" height="28" alt="Ogre"/>
        <span className="chip">srdnlen CTF Finals 2025</span>
      </div>
      <h1 className="display-5 fw-bold mb-2">Get Outta My Swamp! 🐸</h1>
      <p className="lead">
        Welcome to the official portal of <strong>Shrek community</strong> — a shrine to Shrek and swamp memes.
        Your quest: obtain the <strong>secret</strong> gingerbread's recipe.
      </p>
      <div className="d-flex gap-2 mb-4">
        <a className="btn btn-ogre" href="/login">Login</a>
        <a className="btn btn-outline-light" href="/register">Register</a>
        <a className="btn btn-outline-light" href="/about">About</a>
        <a className="btn btn-outline-light" href="/characters">Characters</a>
      </div>
      <div className="col-md-6">
        <div className="card swamp p-3">
          <h5>Swamp Rules</h5>
          <ul className="mb-0">
            <li>Stay out of me swamp.</li>
            <li>No fairytale creatures without permission.</li>
            <li>Wipe your boots before entering.</li>
            <li>Onions are sacred — respect the layers.</li>
            <li>Noise curfew at sundown.</li>
            <li>No unsolicited singing.</li>
            <li>Respect the outhouse.</li>
            <li>Dragon is always welcome. Donkey… depends.</li>
            <li>No knights, no pitchforks, no torches.</li>
            <li>If you’re lost and end up here, consider yourself lucky if you leave in one piece.</li>
          </ul>
        </div>
      </div>
    </main>
  );
}
