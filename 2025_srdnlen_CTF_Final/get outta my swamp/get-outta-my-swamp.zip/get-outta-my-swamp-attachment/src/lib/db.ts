/* node-only */

import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';

const dbPath = path.join(process.cwd(), 'data', 'users.sqlite');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);

db.prepare(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL
)`).run();

const users = [
  { username: 'donkey', password: 'beans' },
  { username: 'fiona', password: 'bababooey' }
];
for (const u of users) {
  try {
    const hash = bcrypt.hashSync(u.password, 10);
    db.prepare('INSERT INTO users (username, password) VALUES (?, ?)').run(u.username, hash);
  } catch {}
}

export default db;
